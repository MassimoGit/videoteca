package com.corso.videoteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VideotecaApplication {

	public static void main(String[] args) {
		SpringApplication.run(VideotecaApplication.class, args);
	}

}
